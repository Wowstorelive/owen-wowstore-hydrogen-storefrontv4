export default {
  storeDomain: '',
  storeName: 'Your Store Name',
  blogHandle: 'Journal',
  sendGridEndpoint: 'https://api.sendgrid.com/v3',
  enableThankYou: true,
  tawkPropertyId: '',
  tawkWidgetId: '',
  googleMapKey: '',
};
