import groq from 'groq';

export const MODULE_HTML_CONTENT = groq`
  _key,
  margin,
  fullWidth,
  scrollToLoad,
  maxWidth,
  htmlContent,
`;
