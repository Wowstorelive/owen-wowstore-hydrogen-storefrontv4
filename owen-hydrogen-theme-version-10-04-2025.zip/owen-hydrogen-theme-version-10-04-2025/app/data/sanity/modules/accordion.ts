import groq from 'groq';

import {MARK_DEFS} from '../portableText/markDefs';

export const MODULE_ACCORDION = groq`
  _key,
  groups[] {
    _key,
    body[] {
      markDefs[] {
        ${MARK_DEFS}
      }
    },
    title,
  }
`;
