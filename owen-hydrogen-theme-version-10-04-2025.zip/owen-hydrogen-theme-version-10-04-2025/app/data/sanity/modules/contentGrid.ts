import groq from 'groq';

export const MODULE_CONTENT_GRID = groq`
    _key,
    column,
    bodyItems,
    margin,
    maxWidth,
    textAlign
`;
