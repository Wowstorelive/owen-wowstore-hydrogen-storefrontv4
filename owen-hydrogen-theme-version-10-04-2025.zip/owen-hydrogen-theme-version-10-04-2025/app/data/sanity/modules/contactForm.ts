import groq from 'groq';

export const MODULE_CONTACT_FORM = groq`
    _key,
    formTitle,
    textDescription,
    margin
`;
